<?php
require 'vendor/autoload.php';
use Dompdf\Dompdf;
$name = $_GET['name'] ?? 'Student';
$course = $_GET['course'] ?? 'Course';
$html = "<h1>Certificate of Completion</h1><p>This certifies that <strong>$name</strong> has completed <strong>$course</strong>.</p>";
$dompdf = new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'landscape');
$dompdf->render();
$dompdf->stream("certificate.pdf");
?>