<?php
require 'db_config.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['role'];
    $sql = "INSERT INTO users (email, password, role) VALUES (?, ?, ?)";
    $stmt= $conn->prepare($sql);
    echo $stmt->execute([$email, $password, $role]) ? "Signup successful!" : "Error!";
}
?>