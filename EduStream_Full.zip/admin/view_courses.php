<?php
require '../db_config.php';
$stmt = $conn->query("SELECT * FROM courses");
echo "<h2>All Courses</h2><table border='1'><tr><th>ID</th><th>Title</th><th>Category</th><th>Price</th></tr>";
while ($row = $stmt->fetch()) {
    echo "<tr><td>{$row['id']}</td><td>{$row['title']}</td><td>{$row['category']}</td><td>{$row['price']}</td></tr>";
}
echo "</table>";
?>