<?php
require '../db_config.php';
$stmt = $conn->query("SELECT id, email, role FROM users");
echo "<h2>All Users</h2><table border='1'><tr><th>ID</th><th>Email</th><th>Role</th></tr>";
while ($row = $stmt->fetch()) {
    echo "<tr><td>{$row['id']}</td><td>{$row['email']}</td><td>{$row['role']}</td></tr>";
}
echo "</table>";
?>