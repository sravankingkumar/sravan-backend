<?php
require 'db_config.php';
$stmt = $conn->prepare("SELECT * FROM courses");
$stmt->execute();
echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
?>